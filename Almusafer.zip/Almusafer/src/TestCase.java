import org.testng.annotations.Test;
import org.testng.asserts.Assertion;

import net.bytebuddy.description.field.FieldDescription;

import java.sql.Date;
import java.time.Duration;
import java.time.LocalDate;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;
public class TestCase extends Paramter {

	

@BeforeTest
	public void myBeforeTest() {
		driver.get(Thewebsite);
        driver.manage().window().maximize();
		
		
	}
		
		
//	@Test(description="Test number 1")
//	public void checkTheLanguage() {
//     String ActualLanguage=driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div[1]/div[2]/div/a[1]")).getText();	
//	  myAssert.assertEquals(ActualLanguage, ExpectedLanguageArabic);
//	}
//	
//	@Test(description="Test number 2")
//	public void checkCurrency() {
//String ActualCurrency=driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div[1]/div[2]/div/div[1]/div/button")).getText();
//	myAssert.assertEquals(ActualCurrency, ExpectedCurrency);
//		
//	}
//	@Test(description="Test number 3")
//	public void checkTheContactIsCorrect() {
//	String actualNumber=driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div[1]/div[2]/div/a[2]/strong")).getText();
//	myAssert.assertEquals(actualNumber, ExpectedNumber);
//		
//		
//		
//	}
//	@Test(description="Test number 4")
//	public void checkQitafLogo() {
//		WebElement myFooter=driver.findElement(By.tagName("footer"));
//		//دورلي ع كل الصور الي نوعها svg 
//		List<WebElement>ListOfSvg=myFooter.findElements(By.tagName("svg"));
//			//System.out.println(ListOfSvg.size());
//		String ExpectedQitaf="Footer__QitafLogo";
//		
//			for(int i=0;i<ListOfSvg.size();i++)
//		{
//				
//				
//			String checkAtrribute=ListOfSvg.get(i).getAttribute("data-testid");	
//			if(checkAtrribute==null)
//				continue;
//			else if(checkAtrribute.equals("Footer__QitafLogo"))
//				myAssert.assertEquals(checkAtrribute, ExpectedQitaf);
//				
//		}
//	}
//	
//      
//		
//		
//		
//		//طريقه2
//		WebElement DivInmyFooterThatContainsQitafLogo=driver.findElement(By.xpath("//*[@id=\"__next\"]/footer/div[3]/div[3]/div[1]/div[2]/div/div[2]"));
//        List<WebElement>ListOfSvg=DivInmyFooterThatContainsQitafLogo.findElements(By.tagName("svg"));
//        String ExpectedQitaf="Footer__QitafLogo";
//        for(int i=0;i<ListOfSvg.size();i++)
// 		{
//  			String svg=ListOfSvg.get(i).getAttribute("data-testid");	
//  			System.out.println(svg);
//  		   myAssert.assertEquals(svg, ExpectedQitaf);
//   		}
//         
// 		
//        
//	}
//@Test(description="Test number 5")
//public void Hotel_Tab_Is_Not_Selected()
//{
//WebElement hotelPAth=driver.findElement(By.xpath("//*[@id=\"uncontrolled-tab-example-tab-hotels\"]"));
//           String ExpectedAria="false";
//           String ActualariaSelected=  hotelPAth.getAttribute("aria-selected");
//	myAssert.assertEquals(ActualariaSelected,ExpectedAria);
//	
//	
//}
	
	//طريقه2
//WebElement classOfAll=	driver.findElement(By.xpath("//*[@id=\"__next\"]/section[2]/div[4]/div/div/nav"));
//List<WebElement>aHrefOfAll=classOfAll.findElements(By.tagName("a"));
//for(int i=0;i<aHrefOfAll.size();i++) {
//if(aHrefOfAll.get(i).getAttribute("id").equals("uncontrolled-tab-example-tab-hotels")) {
//			
//	String aria_selected=aHrefOfAll.get(i).getAttribute("aria-selected");
//	boolean aria_selectedB=Boolean.parseBoolean(aria_selected);
//	myAssert.assertEquals(actualValueOFAriaSelectedFlight, aria_selectedB);
//}
//}

//@Test(description = "Test number 6")
//public void Flight_depature_date() {
//LocalDate currentDay=LocalDate.now();
//int ExpecteddayOfMonth=currentDay.getDayOfMonth();
//String ActualDay=driver.findElement(By.xpath("//*[@id=\"uncontrolled-tab-example-tabpane-flights\"]/div/div[2]/div[1]/div/div[3]/div/div/div/div[1]/span[2]")).getText();
// int ActualDayI=  Integer.parseInt(ActualDay);
//myAssert.assertEquals(ExpecteddayOfMonth+1, ActualDayI);
//}


//@Test(description = "Test number 7")
//public void Flight_return_date() {
//LocalDate currentDay=LocalDate.now();
//int ExpecteddayOfMonth=currentDay.getDayOfMonth();
//String ActualDay=driver.findElement(By.xpath("//*[@id=\"uncontrolled-tab-example-tabpane-flights\"]/div/div[2]/div[1]/div/div[3]/div/div/div/div[2]/span[2]")).getText();
// int ActualDayI=  Integer.parseInt(ActualDay);
//myAssert.assertEquals(ExpecteddayOfMonth+2, ActualDayI);
//	
//}

//@Test(description = "Test number 8" )//تكرار,invocationCount =1515
//public void RandomcheckTheWebsiteLanguge() {
//
//String []myWebsiteURL= {"https://www.almosafer.com/en","https://www.almosafer.com/ar"};
//int myIndex=rand.nextInt(2);//0 or 1
//driver.get(myWebsiteURL[myIndex]);
//if(driver.getCurrentUrl().contains("ar")) {
//String lang=driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div[1]/div[2]/div/a[1]")).getText();
//myAssert.assertEquals(lang,ExpectedLanguageEnglish);
//	
//}else {
//	String lang=driver.findElement(By.xpath("//*[@id=\"__next\"]/header/div/div[1]/div[2]/div/a[1]")).getText();
//	myAssert.assertEquals(lang,ExpectedLanguageArabic);
//
//	
//	
//}

	
	
//}

@Test(description="Tes number 9",priority = 1)
public void Test_Switch_The_hotel_SearchTab() throws InterruptedException {
	//شو رايك قبل ما تلاقي عنصر تستنا شوي بلكي اجا
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
	String [] WebSitetLang= {"https://www.almosafer.com/en","https://www.almosafer.com/ar"};
    driver.get(WebSitetLang[myIndex]);
    
    
    String [] TypeArabic= {"دبي","جدة"};
    
    
    int myIndexEnglish=rand.nextInt(3);
    String [] TypeEnglish= {"Dubai","Jeddah","Riyadh"};
    
    WebElement Hotel=driver.findElement(By.xpath("//*[@id=\"uncontrolled-tab-example-tab-hotels\"]"));
    Hotel.click();
    WebElement searchBar=driver.findElement(By.xpath("//*[@id=\"uncontrolled-tab-example-tabpane-hotels\"]/div/div/div/div[1]/div/div/div/div/input"));

	     if(driver.getCurrentUrl().contains("ar")) {
    	  
    	  searchBar.sendKeys(TypeArabic[myIndex]);
    	
    	  Thread.sleep(1000);
    	   // searchBar.sendKeys(Keys.chord(Keys.ARROW_DOWN)+Keys.ENTER);//الكرود عشان مش باعت معو تكست 
          //الانتر ما زبطت لانو الويبسايت ما زبطت نفسو معو الانتر 
    	 
    	  
    	  //ياخد التانيه
    	  WebElement searchButtun=  driver.findElement(By.xpath("//*[@id=\"uncontrolled-tab-example-tabpane-hotels\"]/div/div/div/div[4]/button"));
    	  searchBar.sendKeys(Keys.chord(Keys.ARROW_DOWN));
    	  
    	  
    	  searchButtun.click(); 
    }
    	
    	
    else 
    {
 
    	WebElement searchButtun=  driver.findElement(By.xpath("//*[@id=\"uncontrolled-tab-example-tabpane-hotels\"]/div/div/div/div[4]/button"));

	  searchBar.sendKeys(TypeEnglish[myIndexEnglish]+Keys.ARROW_DOWN);//بياخد الاولى
	//  searchBar.sendKeys(Keys.chord(Keys.ARROW_DOWN));
	  
	  
	  searchButtun.click(); 
   
    	
    }
    

}
@Test(description ="Test number 10",priority = 2)
public void randomlySelectNumberOfVisitord() {
	//كل ما اشوف سلكت هيك بعمل
Select mySelector=new Select(driver.findElement(By.xpath("//*[@id=\"__next\"]/section[2]/div/section/div/div/div/div/div[3]/div/select")));
int index=rand.nextInt(2);//0 or 1

mySelector.selectByIndex(index);
	
}

@Test(description ="Test number 11",priority = 3)
public void searchHotel() {
	WebElement searchButtun=driver.findElement(By.xpath("//*[@id=\"__next\"]/section[2]/div/section/div/div/div/div/div[4]/button"));
	searchButtun.click();
	
	
	
	
	
	
}
@Test(description ="Test number 12",priority=4)
public void DoneSearching() {
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));//مكن يستنى خمس ثواني او اكثر او اقل اول ما يلاقيها بحكي
	WebElement searchResult=driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/section/span"));
	
	String TextForSearchResult=searchResult.getText();
	boolean actualResultInWebsite=TextForSearchResult.contains("found")||TextForSearchResult.contains("وجدنا");
	//System.out.println(TextForSearchResult);

	myAssert.assertEquals(actualResultInWebsite, true);
	
	
}
@Test(description ="Test number 13",priority=5)
public void Sorting_Lowest_price_To_High() {
	
	WebElement lowestButtun=driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div[1]/div[2]/section[1]/div/button[2]"));
	lowestButtun.click();
WebElement RightSide=driver.findElement(By.xpath("//*[@id=\"__next\"]/div[2]/div[1]/div[2]"));
	
	
List<WebElement>ThePrices=RightSide.findElements(By.className("Price__Value"));

  
  String PriceOnWebSiteindexZero=ThePrices.get(0).getText();
  int firstItem= Integer.parseInt(PriceOnWebSiteindexZero);
  
  String PriceOnWebSiteindexLast=ThePrices.get(ThePrices.size()-1).getText();
  int LastItem= Integer.parseInt(PriceOnWebSiteindexLast);
  
  myAssert.assertEquals(firstItem<LastItem, true);
  

}
	
	
	
	
	
	

}

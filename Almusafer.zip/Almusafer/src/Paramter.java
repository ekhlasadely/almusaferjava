import java.util.Random;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.Assertion;

public class Paramter {
	static WebDriver driver=new ChromeDriver();//هاي عادي منستخدمها استخدمنا التانيه عشان مرات بتشتغلش
	String Thewebsite="https://www.almosafer.com/en";
   
	Assertion myAssert=new Assertion();

	String ExpectedLanguageArabic="العربية";
	String ExpectedLanguageEnglish="English";
    String ExpectedCurrency="SAR";
    String ExpectwedNumber="+966554400000";
   boolean actualValueOfQitaf;
   boolean actualValueOFAriaSelectedFlight=false;
   Random rand=new Random();
   int myIndex=rand.nextInt(2);

	 //هون منعمل ازا الويبدرايف فوق ما زبطت انا  بعملها
	//add testing library then imported
	//@BeforeTest 
	//public void myBeforeTest() {
//		WebDriverManager.chromedriver().setup();//chrome or fire or anything or edge من المكتبات الي عملناهم webdriver
//		WebDriver driver=new ChromeDriver();
	//	
	//	
	//	
	//}


}
